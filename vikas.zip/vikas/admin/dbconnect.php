<?php

	$link=mysqli_connect("localhost","root","","vikas") or die("Error: connecting database.".mysqli_connect_error());

?>